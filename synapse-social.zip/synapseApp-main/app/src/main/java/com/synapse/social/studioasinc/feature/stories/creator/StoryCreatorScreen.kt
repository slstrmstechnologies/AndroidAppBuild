package com.synapse.social.studioasinc.feature.stories.creator

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import com.synapse.social.studioasinc.R
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.res.stringResource
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.synapse.social.studioasinc.domain.model.Post
import com.synapse.social.studioasinc.domain.model.StoryMediaType
import com.synapse.social.studioasinc.domain.model.StoryPrivacy
import com.synapse.social.studioasinc.feature.shared.theme.SynapseTheme
import dagger.hilt.android.AndroidEntryPoint
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.roundToInt
import java.util.concurrent.Executors
import com.synapse.social.studioasinc.feature.shared.theme.Sizes
import com.synapse.social.studioasinc.feature.shared.theme.Spacing
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaItem
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout

const val EXTRA_SHARED_POST_ID = "shared_post_id"

@AndroidEntryPoint
class StoryCreatorActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedPostId = intent.getStringExtra(EXTRA_SHARED_POST_ID)
        setContent {
            SynapseTheme {
                StoryCreatorScreen(
                    onClose = { finish() },
                    onStoryPosted = { finish() },
                    sharedPostId = sharedPostId
                )
            }
        }
    }
}

@Composable
private fun StoryCameraPreview(
    isFrontCamera: Boolean,
    onGalleryClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context) }

    LaunchedEffect(isFrontCamera) {
        val cameraProvider = ProcessCameraProvider.getInstance(context).get()
        val selector = if (isFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
        cameraProvider.unbindAll()
        cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview)
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(Spacing.Large)
        ) {
            Button(onClick = onGalleryClick) {
                Text(stringResource(R.string.story_open_gallery))
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryCreatorScreen(
    onClose: () -> Unit,
    onStoryPosted: () -> Unit,
    sharedPostId: String? = null,
    viewModel: StoryCreatorViewModel = hiltViewModel(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()

    LaunchedEffect(sharedPostId) {
        if (sharedPostId != null) {
            viewModel.loadSharedPost(sharedPostId)
        }
    }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val mimeType = context.contentResolver.getType(uri)
            viewModel.setMediaFromGallery(uri, mimeType)
        }
    }

    fun launchGallery() {
        galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    LaunchedEffect(state.isPosted) {
        if (state.isPosted) {
            onStoryPosted()
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Black
    ) { innerPadding ->
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(innerPadding)
            .background(Color.Black) // Intentional: story creator requires black background
    ) {
        when {
            state.capturedMediaUri != null || state.sharedPost != null -> {
                StoryEditor(
                    state = state,
                    viewModel = viewModel,
                    onClose = onClose,
                    onStoryPosted = onStoryPosted
                )
            }
            hasCameraPermission -> {
                StoryCameraPreview(
                    isFrontCamera = state.isFrontCamera,
                    onGalleryClick = { launchGallery() }
                )
            }
            else -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.camera_permission_required), color = Color.White)
                }
            }
        }
    }
    } // end Scaffold
} // end StoryCreatorScreen

@Composable
fun StoryEditor(
    state: StoryCreatorState,
    viewModel: StoryCreatorViewModel,
    onClose: () -> Unit,
    onStoryPosted: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isDrawingMode by remember { mutableStateOf(false) }
    var showStickerPicker by remember { mutableStateOf(false) }
    var showPrivacyMenu by remember { mutableStateOf(false) }
    var currentPath by remember { mutableStateOf(emptyList<Offset>()) }
    var currentColor by remember { mutableStateOf(Color.White) }
    var currentStrokeWidth by remember { mutableStateOf(10f) }
    val userProfile by viewModel.userProfile.collectAsState()

    val drawingColors = remember {
        listOf(Color.White, Color.Black, Color.Red, Color(0xFFFF9800), Color.Yellow, Color(0xFF4CAF50), Color.Cyan, Color(0xFF9C27B0))
    }
    val stickerEmojis = remember {
        listOf("😊", "😂", "❤️", "🔥", "✨", "👍", "🎉", "😍", "🙌", "💯", "😎", "🥳")
    }

    val cachedPaths = remember(state.drawings) {
        state.drawings.map { drawing ->
            val path = Path().apply {
                if (drawing.points.isNotEmpty()) {
                    moveTo(drawing.points.first().x, drawing.points.first().y)
                    for (i in 1 until drawing.points.size) {
                        lineTo(drawing.points[i].x, drawing.points[i].y)
                    }
                }
            }
            Pair(path, drawing)
        }
    }

    val activePath = remember(currentPath) {
        Path().apply {
            if (currentPath.isNotEmpty()) {
                moveTo(currentPath.first().x, currentPath.first().y)
                for (i in 1 until currentPath.size) {
                    lineTo(currentPath[i].x, currentPath[i].y)
                }
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        StoryBackground(state)

        StoryDrawingCanvas(
            isDrawingMode = isDrawingMode,
            currentPath = currentPath,
            currentColor = currentColor,
            currentStrokeWidth = currentStrokeWidth,
            cachedPaths = cachedPaths,
            activePath = activePath,
            onPathChange = { currentPath = it },
            onDrawingComplete = { path -> viewModel.addDrawing(path) }
        )

        StoryTextOverlays(
            textOverlays = state.textOverlays,
            onPositionChange = { index, position -> viewModel.updateTextPosition(index, position) },
            onContentChange = { index, content -> viewModel.updateTextContent(index, content) }
        )

        StoryStickerOverlays(
            stickers = state.stickers,
            onPositionChange = { index, position -> viewModel.updateStickerPosition(index, position) }
        )

        StoryTopControls(
            isDrawingMode = isDrawingMode,
            userProfile = userProfile,
            onClose = {
                viewModel.clearCapturedMedia()
                onClose()
            },
            onToggleDrawingMode = { isDrawingMode = !isDrawingMode },
            onAddText = { viewModel.addTextOverlay() },
            onAddSticker = { showStickerPicker = true },
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // Drawing toolbar
        if (isDrawingMode) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = Spacing.Small),
                verticalArrangement = Arrangement.spacedBy(Spacing.Small)
            ) {
                drawingColors.forEach { color ->
                    Box(
                        modifier = Modifier
                            .size(Sizes.IconLarge)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (color == currentColor) Sizes.BorderSelected else Sizes.BorderThin,
                                color = MaterialTheme.colorScheme.onPrimary,
                                shape = CircleShape
                            )
                            .clickable { currentColor = color }
                    )
                }
                Spacer(Modifier.height(Spacing.Small))
                // Undo button
                IconButton(
                    onClick = { viewModel.undoDrawing() },
                    modifier = Modifier
                        .size(Sizes.IconLarge)
                        .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo", tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }

        // Sticker picker
        if (showStickerPicker) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable { showStickerPicker = false },
                contentAlignment = Alignment.Center
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(Sizes.CornerLarge))
                        .padding(Spacing.Medium),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.Medium)
                ) {
                    items(stickerEmojis) { emoji ->
                        Text(
                            text = emoji,
                            fontSize = 36.sp,
                            modifier = Modifier.clickable {
                                viewModel.addSticker(emoji)
                                showStickerPicker = false
                            }
                        )
                    }
                }
            }
        }

        // Privacy menu
        Box(modifier = Modifier.align(Alignment.BottomStart).padding(Spacing.Medium)) {
            TextButton(onClick = { showPrivacyMenu = true }) {
                Text(
                    text = state.selectedPrivacy.name.replace('_', ' '),
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.labelLarge
                )
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
            }
            DropdownMenu(expanded = showPrivacyMenu, onDismissRequest = { showPrivacyMenu = false }) {
                StoryPrivacy.entries.forEach { privacy ->
                    DropdownMenuItem(
                        text = { Text(privacy.name.replace('_', ' ')) },
                        onClick = {
                            viewModel.setPrivacy(privacy)
                            showPrivacyMenu = false
                        }
                    )
                }
            }
        }

        StoryBottomControls(
            isPosting = state.isPosting,
            privacyName = state.selectedPrivacy.name,
            onPost = { viewModel.postStory() },
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }

    LaunchedEffect(state.isPosted) {
        if (state.isPosted) {
            onStoryPosted()
        }
    }
}

@Composable
private fun StoryDrawingCanvas(
    isDrawingMode: Boolean,
    currentPath: List<Offset>,
    currentColor: Color,
    currentStrokeWidth: Float,
    cachedPaths: List<Pair<Path, DrawingPath>>,
    activePath: Path,
    onPathChange: (List<Offset>) -> Unit,
    onDrawingComplete: (DrawingPath) -> Unit,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(isDrawingMode) {
                if (isDrawingMode) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            onPathChange(listOf(offset))
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            onPathChange(currentPath + change.position)
                        },
                        onDragEnd = {
                            if (currentPath.isNotEmpty()) {
                                onDrawingComplete(
                                    DrawingPath(
                                        points = currentPath,
                                        color = currentColor,
                                        strokeWidth = currentStrokeWidth
                                    )
                                )
                                onPathChange(emptyList())
                            }
                        }
                    )
                }
            }
    ) {
        cachedPaths.forEach { (path, drawing) ->
            if (drawing.points.size > 1) {
                drawPath(
                    path = path,
                    color = drawing.color,
                    style = Stroke(
                        width = drawing.strokeWidth,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }

        if (currentPath.size > 1) {
            drawPath(
                path = activePath,
                color = currentColor,
                style = Stroke(
                    width = currentStrokeWidth,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}

@Composable
private fun StoryTextOverlays(
    textOverlays: List<TextOverlay>,
    onPositionChange: (Int, Offset) -> Unit,
    onContentChange: (Int, String) -> Unit,
    modifier: Modifier = Modifier
) {
    textOverlays.forEachIndexed { index, overlay ->
        Box(
            modifier = modifier
                .offset {
                    IntOffset(overlay.position.x.roundToInt(), overlay.position.y.roundToInt())
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onPositionChange(
                            index,
                            Offset(
                                overlay.position.x + dragAmount.x,
                                overlay.position.y + dragAmount.y
                            )
                        )
                    }
                }
        ) {
            TextField(
                value = overlay.text,
                onValueChange = { onContentChange(index, it) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedTextColor = overlay.color,
                    unfocusedTextColor = overlay.color,
                    cursorColor = overlay.color,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = (24 * overlay.scale).sp,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

@Composable
private fun StoryStickerOverlays(
    stickers: List<StickerOverlay>,
    onPositionChange: (Int, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    stickers.forEachIndexed { index, sticker ->
        Text(
            text = sticker.emoji,
            fontSize = (48 * sticker.scale).sp,
            modifier = modifier
                .offset {
                    IntOffset(sticker.position.x.roundToInt(), sticker.position.y.roundToInt())
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onPositionChange(
                            index,
                            Offset(
                                sticker.position.x + dragAmount.x,
                                sticker.position.y + dragAmount.y
                            )
                        )
                    }
                }
        )
    }
}

@Composable
private fun StoryTopControls(
    isDrawingMode: Boolean,
    userProfile: com.synapse.social.studioasinc.domain.model.User?,
    onClose: () -> Unit,
    onToggleDrawingMode: () -> Unit,
    onAddText: () -> Unit,
    onAddSticker: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(Spacing.Medium),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.Default.Close, contentDescription = stringResource(R.string.story_discard), tint = MaterialTheme.colorScheme.onPrimary)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onAddText) {
                Text(
                    stringResource(R.string.story_text_button_label),
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )
            }
            IconButton(onClick = onAddSticker) {
                Icon(Icons.Default.Face, contentDescription = stringResource(R.string.story_add_sticker), tint = MaterialTheme.colorScheme.onPrimary)
            }
            IconButton(onClick = onToggleDrawingMode) {
                Icon(
                    if (isDrawingMode) Icons.Default.Edit else Icons.Default.Edit,
                    contentDescription = stringResource(R.string.story_draw),
                    tint = if (isDrawingMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimary
                )
            }
        }

        if (userProfile?.avatar != null) {
            AsyncImage(
                model = userProfile.avatar,
                contentDescription = null,
                modifier = Modifier
                    .size(Sizes.IconMassive)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .size(Sizes.IconMassive)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Person,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(Sizes.IconDefault)
                )
            }
        }
    }
}

@Composable
private fun StoryBottomControls(
    isPosting: Boolean,
    privacyName: String,
    onPost: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onPost,
        modifier = modifier.padding(Spacing.Medium)
    ) {
        if (isPosting) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(Sizes.IconLarge))
        } else {
            Text(stringResource(R.string.post_to_privacy, privacyName))
        }
    }
}

@Composable
private fun StoryBackground(state: StoryCreatorState) {
    val mediaUri = state.capturedMediaUri
    if (mediaUri != null) {
        if (state.mediaType == StoryMediaType.VIDEO) {
            val context = LocalContext.current
            val exoPlayer = remember(mediaUri) {
                ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(mediaUri))
                    repeatMode = ExoPlayer.REPEAT_MODE_ONE
                    playWhenReady = true
                    prepare()
                }
            }
            DisposableEffect(exoPlayer) { onDispose { exoPlayer.release() } }
            AndroidView(
                factory = {
                    PlayerView(it).apply {
                        player = exoPlayer
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            AsyncImage(
                model = mediaUri,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    } else if (state.sharedPost != null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.story_shared_post_editor), color = Color.White)
        }
    }
}
