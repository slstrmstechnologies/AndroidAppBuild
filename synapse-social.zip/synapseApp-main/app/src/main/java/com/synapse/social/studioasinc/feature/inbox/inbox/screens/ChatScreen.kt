package com.synapse.social.studioasinc.feature.inbox.inbox.screens

import com.synapse.social.studioasinc.feature.shared.components.picker.PickedFile
import com.synapse.social.studioasinc.feature.shared.components.picker.SynapseFilePicker


import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageContractOptions
import com.canhub.cropper.CropImageOptions
import com.canhub.cropper.CropImageView


import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Animatable
import kotlinx.coroutines.launch
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextLayoutResult

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue


import com.synapse.social.studioasinc.feature.shared.components.post.ReactionPicker
import com.synapse.social.studioasinc.domain.model.ReactionType as AppReactionType
import com.synapse.social.studioasinc.shared.domain.model.ReactionType as SharedReactionType
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.vector.rememberVectorPainter

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.OpenableColumns
import com.synapse.social.studioasinc.feature.shared.components.UserAvatarWithStatus
import coil.compose.AsyncImage
import coil.decode.SvgDecoder
import coil.request.ImageRequest
import androidx.compose.ui.res.stringResource
import com.synapse.social.studioasinc.R

import androidx.compose.ui.draw.blur
import com.synapse.social.studioasinc.shared.domain.model.settings.WallpaperType
import com.synapse.social.studioasinc.shared.domain.model.settings.ChatThemePreset
import com.synapse.social.studioasinc.feature.inbox.inbox.ChatViewModel
import com.synapse.social.studioasinc.feature.inbox.inbox.components.ChatShimmer
import com.synapse.social.studioasinc.feature.inbox.inbox.components.ChatTopAppBar
import com.synapse.social.studioasinc.feature.inbox.inbox.components.MessageContextMenu
import com.synapse.social.studioasinc.feature.inbox.inbox.components.MessageSummaryDialog
import com.synapse.social.studioasinc.feature.inbox.inbox.components.ChatSummaryDialog
import com.synapse.social.studioasinc.feature.inbox.inbox.components.ChatInputBar
import com.synapse.social.studioasinc.feature.inbox.inbox.components.MediaPreviewDialog
import com.synapse.social.studioasinc.feature.inbox.inbox.components.DateDividerChip
import com.synapse.social.studioasinc.feature.inbox.inbox.components.GroupPosition
import com.synapse.social.studioasinc.feature.inbox.inbox.components.MessageBubble
import com.synapse.social.studioasinc.feature.inbox.inbox.components.UnreadDividerRow
import com.synapse.social.studioasinc.feature.inbox.inbox.components.isWithinTimeThreshold
import com.synapse.social.studioasinc.feature.inbox.inbox.models.ChatListItem
import com.synapse.social.studioasinc.feature.shared.theme.Spacing
import com.synapse.social.studioasinc.feature.shared.theme.StatusOnline
import com.synapse.social.studioasinc.feature.shared.theme.StatusRead
import com.synapse.social.studioasinc.feature.shared.theme.LightPrimaryContainer
import com.synapse.social.studioasinc.feature.shared.theme.ForestBubbleBackground
import com.synapse.social.studioasinc.feature.shared.theme.ForestBubbleText
import com.synapse.social.studioasinc.feature.shared.theme.SunsetBubbleBackground
import com.synapse.social.studioasinc.feature.shared.theme.SunsetBubbleText
import com.synapse.social.studioasinc.feature.shared.theme.Gray200
import com.synapse.social.studioasinc.feature.shared.theme.Gray900
import com.synapse.social.studioasinc.feature.shared.theme.DarkPrimaryContainer
import com.synapse.social.studioasinc.feature.shared.theme.LightOnPrimaryContainer
import com.synapse.social.studioasinc.shared.domain.model.chat.DisappearingMode
import com.synapse.social.studioasinc.shared.domain.model.chat.Message
import com.synapse.social.studioasinc.shared.domain.model.chat.MessageType
import com.synapse.social.studioasinc.feature.shared.components.LinkPreviewCard
import com.synapse.social.studioasinc.feature.shared.components.LinkPreviewViewModel
import com.synapse.social.studioasinc.feature.shared.utils.UrlUtils
import com.synapse.social.studioasinc.shared.domain.usecase.GetLinkMetadataUseCase
import androidx.hilt.navigation.compose.hiltViewModel

import com.synapse.social.studioasinc.shared.domain.service.AudioRecorder
import kotlinx.coroutines.delay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import com.synapse.social.studioasinc.feature.shared.theme.Sizes
import com.synapse.social.studioasinc.core.util.IntentUtils

private const val MAX_BLUR_RADIUS = 50f

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    linkPreviewViewModel: LinkPreviewViewModel = hiltViewModel(),
    chatId: String,
    participantId: String? = null,
    initialParticipantName: String? = null,
    initialParticipantAvatar: String? = null,
    onNavigateBack: () -> Unit,
    onNavigateToGroupInfo: (String, String) -> Unit = { _, _ -> },
    onNavigateToUserMoreOptions: (String) -> Unit = {},
    viewModel: ChatViewModel = hiltViewModel()
) {
    // Initialize the ViewModel with the chat ID
    LaunchedEffect(chatId) {
        viewModel.initialize(chatId, participantId)
    }

    val messages by viewModel.messages.collectAsState()
    val chatItems by viewModel.chatItems.collectAsState()
    val inputText by viewModel.inputText.collectAsState()

    val isLoading by viewModel.isLoading.collectAsState()
    val participantProfile by viewModel.participantProfile.collectAsState()
    val isParticipantActive by viewModel.isParticipantActive.collectAsState()

    val error by viewModel.error.collectAsState()
    val editingMessage by viewModel.editingMessage.collectAsState()
    val typingStatus by viewModel.typingStatus.collectAsState()
    val smartReplies by viewModel.smartReplies.collectAsState()
    val chatSummary by viewModel.chatSummary.collectAsState()
    val messageSummary by viewModel.messageSummary.collectAsState()
    val isSummarizingMessage by viewModel.isSummarizingMessage.collectAsState()
    val canSendMessage by viewModel.canSendMessage.collectAsState()
    val selectedMessageIds by viewModel.selectedMessageIds.collectAsState()
    val replyingToMessage by viewModel.replyingToMessage.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val currentUserId = viewModel.currentUserId ?: ""

    val chatWallpaperType by viewModel.chatWallpaperType.collectAsState()
    val chatWallpaperValue by viewModel.chatWallpaperValue.collectAsState()
    val chatWallpaperBlur by viewModel.chatWallpaperBlur.collectAsState()
    val chatFontScale by viewModel.chatFontScale.collectAsState()
    val chatThemePreset by viewModel.chatThemePreset.collectAsState()
    val chatMessageCornerRadius by viewModel.chatMessageCornerRadius.collectAsState()


    var selectedMessageForMenu by remember { mutableStateOf<Message?>(null) }

    @Suppress("DEPRECATION")
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    val listState = rememberLazyListState()
    val context = LocalContext.current

    var selectedMediaUri by remember { mutableStateOf<Uri?>(null) }
    var selectedMediaType by remember { mutableStateOf("") }

    val handleFileSelection = { uri: Uri?, type: String, caption: String? ->
        uri?.let {
            val contentResolver = context.contentResolver
            val mimeType = contentResolver.getType(it) ?: ""
            var fileName = "attachment"
            contentResolver.query(it, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) fileName = cursor.getString(index)
                }
            }

            val filePath = com.synapse.social.studioasinc.core.util.FileUtils.validateAndCleanPath(context, it.toString())
            if (filePath != null) {
                viewModel.uploadAndSendMedia(
                    filePath = filePath,
                    fileName = fileName,
                    contentType = mimeType,
                    messageType = type,
                    caption = caption
                )
            }
        }
    }


    // Show toast for E2EE errors
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            android.widget.Toast.makeText(context, it, android.widget.Toast.LENGTH_LONG).show()
            viewModel.clearToast()
        }
    }

    // Auto-scroll to bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(0)
        }
    }

    Scaffold(
        topBar = {
            val disappearingMode by viewModel.disappearingMode.collectAsState()
            ChatTopAppBar(
                selectedMessageIds = selectedMessageIds,
                messages = messages,
                participantId = participantId,
                participantProfile = participantProfile,
                initialParticipantName = initialParticipantName,
                initialParticipantAvatar = initialParticipantAvatar,
                typingStatus = typingStatus,
                isParticipantActive = isParticipantActive,
                chatId = chatId,
                disappearingMode = disappearingMode,
                isLocked = viewModel.isChatLocked(),
                onClearSelection = viewModel::clearSelection,
                onDeleteSelectedMessages = viewModel::deleteSelectedMessages,
                onNavigateBack = onNavigateBack,
                onSummarizeChat = viewModel::summarizeChat,
                onNavigateToGroupInfo = onNavigateToGroupInfo,
                onNavigateToUserMoreOptions = onNavigateToUserMoreOptions,
                onSetDisappearingMode = viewModel::setDisappearingMode,
                onLockChat = viewModel::lockCurrentChat,
                onUnlockChat = viewModel::unlockCurrentChat
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(top = paddingValues.calculateTopPadding())
                .imePadding()
        ) {

            if (!isLoading || messages.isNotEmpty()) {
                when (chatWallpaperType) {
                    WallpaperType.SOLID_COLOR -> {
                        // Do nothing, default surface color
                    }
                    WallpaperType.DEFAULT -> {
                         AsyncImage(
                            model = context.resources.getIdentifier("pattern_11", "raw", context.packageName), // Default pattern or just surface color
                            contentDescription = "Background",
                            modifier = Modifier.fillMaxSize().blur(radius = (chatWallpaperBlur * MAX_BLUR_RADIUS).dp),
                            contentScale = ContentScale.Crop,
                            alpha = 0.5f
                         )
                    }
                    WallpaperType.PATTERN, WallpaperType.PRESET_IMAGE -> {
                        chatWallpaperValue?.let { value ->
                            val context = LocalContext.current
                            val resId = context.resources.getIdentifier(value, "raw", context.packageName)
                            if (resId != 0) {
                                 AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current)
                                        .data(resId)
                                        .apply {
                                            if (chatWallpaperType == WallpaperType.PATTERN) {
                                                decoderFactory(SvgDecoder.Factory())
                                            }
                                        }
                                        .build(),
                                    contentDescription = "Background",
                                    modifier = Modifier.fillMaxSize().blur(radius = (chatWallpaperBlur * MAX_BLUR_RADIUS).dp),
                                    contentScale = ContentScale.Crop
                                 )
                            }
                        }
                    }
                }
            }

            when {
                isLoading && messages.isEmpty() -> {
                    ChatShimmer(modifier = Modifier.fillMaxSize())
                }
                error != null && messages.isEmpty() -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = error ?: "Something went wrong",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.height(Spacing.Small))
                        TextButton(onClick = { viewModel.initialize(chatId, participantId) }) {
                            Text(stringResource(R.string.action_retry))
                        }
                    }
                }
                else -> {
                    val messagesMap = remember(messages) {
                        messages.associateBy { it.id }
                    }
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize(),
                        // Extra bottom padding so last messages aren't hidden behind the floating input
                        contentPadding = PaddingValues(
                            start = Spacing.Medium,
                            end = Spacing.Medium,
                            top = Spacing.Medium,
                            bottom = Sizes.WidthLarge
                        ),
                        verticalArrangement = Arrangement.spacedBy(Spacing.ExtraSmall),
                        reverseLayout = true
                    ) {
                        val reversedItems = chatItems.reversed()
                        itemsIndexed(reversedItems, key = { index, item ->
                            when (item) {
                                 is ChatListItem.DateDivider -> "date_${item.label}_$index"
                                 is ChatListItem.UnreadDivider -> "unread_$index"
                                 is ChatListItem.MessageItem -> item.message.id
                             }
                         }) { index, item ->
                            when (item) {
                                is ChatListItem.DateDivider -> DateDividerChip(label = item.label)
                                is ChatListItem.UnreadDivider -> UnreadDividerRow(count = item.count)
                                is ChatListItem.MessageItem -> {
                                    val message = item.message
                                    val prevMessageItem = reversedItems.drop(index + 1).filterIsInstance<ChatListItem.MessageItem>().firstOrNull()
                                    val nextMessageItem = reversedItems.take(index).filterIsInstance<ChatListItem.MessageItem>().lastOrNull()
                                    val hasOlder = prevMessageItem != null && prevMessageItem.message.senderId == message.senderId && isWithinTimeThreshold(prevMessageItem.message.createdAt, message.createdAt)
                                    val hasNewer = nextMessageItem != null && nextMessageItem.message.senderId == message.senderId && isWithinTimeThreshold(message.createdAt, nextMessageItem.message.createdAt)
                                    val position = when {
                                        !hasOlder && !hasNewer -> GroupPosition.SINGLE
                                        !hasOlder && hasNewer -> GroupPosition.FIRST
                                        hasOlder && !hasNewer -> GroupPosition.LAST
                                        else -> GroupPosition.MIDDLE
                                    }
                                    val isSelected = message.id in selectedMessageIds
                                    MessageBubble(
                                        message = message,
                                        isFromMe = message.isFromMe(currentUserId),
                                        position = position,
                                        isSelected = isSelected,
                                        onToggleSelection = { if (selectedMessageIds.isNotEmpty()) message.id?.let { viewModel.toggleMessageSelection(it) } },
                                        onSwipeToReply = { viewModel.setReplyingToMessage(message) },
                                        replyToMessage = message.replyToId?.let { messagesMap[it] },
                                        onLongClick = {
                                            if (selectedMessageIds.isNotEmpty()) message.id?.let { viewModel.toggleMessageSelection(it) }
                                            else selectedMessageForMenu = message
                                        },
                                        onReactionSelected = { reaction -> message.id?.let { viewModel.toggleMessageReaction(it, reaction) } },
                                        fontScale = chatFontScale,
                                        cornerRadius = chatMessageCornerRadius,
                                        themePreset = chatThemePreset
                                    )
                                }
                            }
                        }
                    }

                    // Context Menu and Reactions for messages
                    if (selectedMessageForMenu != null) {
                        MessageContextMenu(
                            selectedMessage = selectedMessageForMenu,
                            currentUserId = currentUserId,
                            onDismissRequest = { selectedMessageForMenu = null },
                            onReactionSelected = viewModel::toggleMessageReaction,
                            onStartEditing = viewModel::startEditing,
                            onDeleteMessageForMe = viewModel::deleteMessageForMe,
                            onDeleteMessageForEveryone = viewModel::deleteMessage,
                            onSummarizeMessage = viewModel::summarizeMessage
                        )
                    }
                }
            }

            // ── Message Summary Dialog ──
            MessageSummaryDialog(
                isSummarizingMessage = isSummarizingMessage,
                messageSummary = messageSummary,
                onDismissRequest = viewModel::clearMessageSummary
            )

            // ── Bottom fade gradient so messages appear to fade behind the floating input ──
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(Sizes.HeightMedium)
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                MaterialTheme.colorScheme.surface
                            )
                        )
                    )
            )

            // ── Floating Input Bar ──
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
            ) {
                ChatInputBar(
                    replyingToMessage = replyingToMessage,
                    editingMessage = editingMessage,
                    smartReplies = smartReplies,
                    inputText = inputText,
                    canSendMessage = canSendMessage,
                    currentUserId = currentUserId,
                    participantDisplayName = participantProfile?.displayName,
                    getLinkMetadataUseCase = linkPreviewViewModel.getLinkMetadataUseCase,
                    context = context,
                    onInputTextChange = viewModel::onInputTextChange,
                    onSendMessage = viewModel::sendMessage,
                    onCancelReply = viewModel::cancelReply,
                    onCancelEditing = viewModel::cancelEditing,
                    onUploadAndSendMedia = viewModel::uploadAndSendMedia
                )
            }

            // Chat Summary Dialog
            ChatSummaryDialog(
                chatSummary = chatSummary,
                onDismissRequest = viewModel::clearSummary
            )
        }
    }

    selectedMediaUri?.let { uri ->
        MediaPreviewDialog(
            selectedMediaUri = uri,
            selectedMediaType = selectedMediaType,
            context = context,
            onDismissRequest = {
                selectedMediaUri = null
            },
            onSendMedia = { finalUri, type, caption ->
                handleFileSelection(finalUri, type, caption)
                selectedMediaUri = null
            }
        )
    }
}

