package com.synapse.social.studioasinc.feature.shared.theme

import androidx.compose.ui.graphics.Color


val SynapseBlue = Color(0xFF1976D2)
val SynapseDarkBlue = Color(0xFF00497D)
val SynapseLightBlue = Color(0xFFBBDEFB)


val LightPrimary = Color(0xFF6750A4)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFEADDFF)
val LightOnPrimaryContainer = Color(0xFF21005D)
val LightSecondary = Color(0xFF625B71)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFE8DEF8)
val LightOnSecondaryContainer = Color(0xFF1D192B)
val LightTertiary = Color(0xFF7D5260)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFFFD8E4)
val LightOnTertiaryContainer = Color(0xFF31111D)
val LightError = Color(0xFFB3261E)
val LightOnError = Color(0xFFFFFFFF)
val LightErrorContainer = Color(0xFFF9DEDC)
val LightOnErrorContainer = Color(0xFF410E0B)
val LightOutline = Color(0xFF79747E)
val LightBackground = Color(0xFFFFFBFE)
val LightOnBackground = Color(0xFF1C1B1F)
val LightSurface = Color(0xFFFFFBFE)
val LightOnSurface = Color(0xFF1C1B1F)
val LightSurfaceVariant = Color(0xFFE7E0EC)
val LightOnSurfaceVariant = Color(0xFF49454F)
val LightInverseSurface = Color(0xFF313033)
val LightInverseOnSurface = Color(0xFFF4EFF4)
val LightInversePrimary = Color(0xFFD0BCFF)
val LightShadow = Color(0xFF000000)
val LightSurfaceTint = Color(0xFF6750A4)
val LightOutlineVariant = Color(0xFFCAC4D0)
val LightScrim = Color(0xFF000000)


val DarkPrimary = Color(0xFFD0BCFF)
val DarkOnPrimary = Color(0xFF381E72)
val DarkPrimaryContainer = Color(0xFF4F378B)
val DarkOnPrimaryContainer = Color(0xFFEADDFF)
val DarkSecondary = Color(0xFFCCC2DC)
val DarkOnSecondary = Color(0xFF332D41)
val DarkSecondaryContainer = Color(0xFF4A4458)
val DarkOnSecondaryContainer = Color(0xFFE8DEF8)
val DarkTertiary = Color(0xFFEFB8C8)
val DarkOnTertiary = Color(0xFF492532)
val DarkTertiaryContainer = Color(0xFF633B48)
val DarkOnTertiaryContainer = Color(0xFFFFD8E4)
val DarkError = Color(0xFFF2B8B5)
val DarkOnError = Color(0xFF601410)
val DarkErrorContainer = Color(0xFF8C1D18)
val DarkOnErrorContainer = Color(0xFFF9DEDC)
val DarkOutline = Color(0xFF938F99)
val DarkBackground = Color(0xFF1C1B1F)
val DarkOnBackground = Color(0xFFE6E1E5)
val DarkSurface = Color(0xFF1C1B1F)
val DarkOnSurface = Color(0xFFE6E1E5)
val DarkSurfaceVariant = Color(0xFF2B2930)
val DarkOnSurfaceVariant = Color(0xFFCAC4D0)
val DarkInverseSurface = Color(0xFFE6E1E5)
val DarkInverseOnSurface = Color(0xFF313033)
val DarkInversePrimary = Color(0xFF6750A4)
val DarkShadow = Color(0xFF000000)
val DarkSurfaceTint = Color(0xFFD0BCFF)
val DarkOutlineVariant = Color(0xFF49454F)
val DarkScrim = Color(0xFF000000)


val StatusOnline = Color(0xFF4CAF50)

// Chat theme preset colors
val ForestBubbleBackground = Color(0xFFE8F5E9)
val ForestBubbleText = Color(0xFF1B5E20)
val SunsetBubbleBackground = Color(0xFFFBE9E7)
val SunsetBubbleText = Color(0xFFBF360C)
val SunsetAccent = Color(0xFFFF5722)

// Interaction colors
val InteractionIconDefault = Color(0xFF657786)
val InteractionLikeActive = Color(0xFFE0245E)
val InteractionRepostActive = Color(0xFF17BF63)

// Status colors
val StatusRead = Color(0xFF4FC3F7)
val StatusOffline = Color(0xFF9E9E9E)

// Accent colors
val AccentOrange = Color(0xFFFFA500)
val AccentBlue = Color(0xFF2196F3)
val AccentYellow = Color(0xFFFFC107)

// Neutral grays
val Gray200 = Color(0xFFE0E0E0)
val Gray300 = Color(0xFFBDBDBD)
val Gray500 = Color(0xFF9E9E9E)
val Gray700 = Color(0xFF616161)
val Gray900 = Color(0xFF212121)


// Chat Preset Colors
val ChatPresetColor1 = Color(0xFFE8F5E9)
val ChatPresetColor2 = Color(0xFFFBE9E7)
val ChatPresetColor3 = Color(0xFF1B5E20)
val ChatPresetColor4 = Color(0xFFBF360C)
val ChatPresetColor5 = Color(0xFFFF5722)
val ChatPresetColor6 = Color(0xFF9E9E9E)
val ChatPresetColor7 = Color(0xFFE0E0E0)
